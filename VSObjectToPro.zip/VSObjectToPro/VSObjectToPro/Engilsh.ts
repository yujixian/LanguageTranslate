<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="en">
<context>
    <name>QWidget</name>
    <message>
        <location filename="Test1.cpp" line="8"/>
        <source>测试中文</source>
        <translation type="unfinished">test chinese</translation>
    </message>
</context>
<context>
    <name>Test1</name>
    <message>
        <location filename="Test1.ui" line="14"/>
        <source>Test1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="Test1.ui" line="26"/>
        <source>中文</source>
        <translation type="unfinished">chinese</translation>
    </message>
    <message>
        <location filename="Test1.ui" line="39"/>
        <source>测试</source>
        <translation type="unfinished">test</translation>
    </message>
</context>
<context>
    <name>VSObjectToProClass</name>
    <message>
        <location filename="VSObjectToPro.ui" line="14"/>
        <source>VSObjectToPro</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="VSObjectToPro.ui" line="27"/>
        <location filename="VSObjectToPro.ui" line="54"/>
        <source>中文</source>
        <translation type="unfinished">Chinese111</translation>
    </message>
    <message>
        <location filename="VSObjectToPro.ui" line="40"/>
        <source>测试</source>
        <translation type="unfinished">test111</translation>
    </message>
    <message>
        <location filename="VSObjectToPro.ui" line="59"/>
        <source>英文</source>
        <translation type="unfinished">English111</translation>
    </message>
</context>
</TS>
