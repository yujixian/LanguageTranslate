<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="zh_CN">
<context>
    <name>QWidget</name>
    <message>
        <location filename="Test1.cpp" line="8"/>
        <source>测试中文</source>
        <translation type="unfinished">测试中文</translation>
    </message>
</context>
<context>
    <name>Test1</name>
    <message>
        <location filename="Test1.ui" line="14"/>
        <source>Test1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="Test1.ui" line="26"/>
        <source>中文</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="Test1.ui" line="39"/>
        <source>测试</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>VSObjectToProClass</name>
    <message>
        <location filename="VSObjectToPro.ui" line="14"/>
        <source>VSObjectToPro</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="VSObjectToPro.ui" line="27"/>
        <location filename="VSObjectToPro.ui" line="54"/>
        <source>中文</source>
        <translatorcomment>中文</translatorcomment>
        <translation type="unfinished">中文</translation>
    </message>
    <message>
        <location filename="VSObjectToPro.ui" line="40"/>
        <source>测试</source>
        <translatorcomment>测试</translatorcomment>
        <translation type="unfinished">测试</translation>
    </message>
    <message>
        <location filename="VSObjectToPro.ui" line="59"/>
        <source>英文</source>
        <translatorcomment>英文</translatorcomment>
        <translation type="unfinished">英文</translation>
    </message>
</context>
</TS>
